import { createClient } from '@supabase/supabase-js';
import { logger } from '../utils/logger';

const supabaseUrl = process.env.SUPABASE_URL!;
const supabaseKey = process.env.SUPABASE_ANON_KEY!;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Supabase配置缺失：SUPABASE_URL 和 SUPABASE_ANON_KEY 是必需的');
}

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: false,
    autoRefreshToken: false
  }
});

// 模板接口
export interface Template {
  id: string;
  category_id: string;
  name_en: string;
  name_zh: string;
  description_en: string;
  description_zh: string;
  prompt_content: string;
  no: number;
}

// 项目接口
export interface Project {
  id: string;
  name: string;
  description: string;
  website_url?: string;
  user_id: string;
  is_default: boolean;
}

// 模板版本接口
export interface TemplateVersion {
  id: string;
  template_id: string;
  project_id: string;
  created_by: string;
  input_content: string;
  output_content: any;
  version_number: number;
  is_active: boolean;
  created_at: string;
}

/**
 * 获取模板列表
 */
export async function getTemplates(options: {
  categoryCode?: string;
  limit?: number;
  offset?: number;
} = {}) {
  const { categoryCode, limit = 50, offset = 0 } = options;

  try {
    let query = supabase
      .from('templates')
      .select(`
        *,
        template_categories!inner(*)
      `)
      .order('no');

    if (categoryCode) {
      query = query.eq('template_categories.id', categoryCode);
    }

    if (limit > 0) {
      query = query.range(offset, offset + limit - 1);
    }

    const { data, error } = await query;

    if (error) {
      logger.error('获取模板失败', error);
      throw error;
    }

    return data as Template[];
  } catch (error) {
    logger.error('获取模板异常', error);
    throw error;
  }
}

/**
 * 获取项目列表
 */
export async function getProjects(options: {
  userId?: string;
  tableName?: string;
  limit?: number;
  offset?: number;
} = {}) {
  const { userId, tableName = 'user_projects', limit = 50, offset = 0 } = options;

  try {
    let query = supabase
      .from(tableName)
      .select('*')
      .order('created_at', { ascending: false });

    if (userId) {
      query = query.eq('user_id', userId);
    }

    if (limit > 0) {
      query = query.range(offset, offset + limit - 1);
    }

    const { data, error } = await query;

    if (error) {
      logger.error('获取项目失败', error);
      throw error;
    }

    return data as Project[];
  } catch (error) {
    logger.error('获取项目异常', error);
    throw error;
  }
}

/**
 * 检查模板版本是否存在
 */
export async function checkExistingVersion(
  templateId: string,
  projectId: string,
  language: string = 'zh'
): Promise<number> {
  try {
    const { data, error } = await supabase
      .from('template_versions')
      .select('version_number')
      .eq('template_id', templateId)
      .eq('project_id', projectId)
      .order('version_number', { ascending: false })
      .limit(1);

    if (error) {
      logger.error('检查版本失败', error);
      return 1;
    }

    return data && data.length > 0 ? data[0].version_number + 1 : 1;
  } catch (error) {
    logger.error('版本检查异常', error);
    return 1;
  }
}

/**
 * 保存模板版本
 */
export async function saveTemplateVersion(version: {
  template_id: string;
  project_id: string;
  created_by: string;
  input_content: string;
  output_content: any;
  version_number?: number;
}): Promise<TemplateVersion> {
  try {
    const { data, error } = await supabase
      .from('template_versions')
      .insert({
        template_id: version.template_id,
        project_id: version.project_id,
        created_by: version.created_by,
        input_content: version.input_content,
        output_content: version.output_content,
        is_active: true
      })
      .select()
      .single();

    if (error) {
      logger.error('保存模板版本失败', error);
      throw error;
    }

    logger.info('模板版本保存成功', { versionId: data.id });
    return data as TemplateVersion;
  } catch (error) {
    logger.error('保存模板版本异常', error);
    throw error;
  }
}

/**
 * 获取模板版本历史
 */
export async function getTemplateVersions(
  templateId: string,
  projectId?: string
): Promise<TemplateVersion[]> {
  try {
    let query = supabase
      .from('template_versions')
      .select('*')
      .eq('template_id', templateId)
      .order('created_at', { ascending: false });

    if (projectId) {
      query = query.eq('project_id', projectId);
    }

    const { data, error } = await query;

    if (error) {
      logger.error('获取模板版本失败', error);
      throw error;
    }

    return data as TemplateVersion[];
  } catch (error) {
    logger.error('获取模板版本异常', error);
    throw error;
  }
} 