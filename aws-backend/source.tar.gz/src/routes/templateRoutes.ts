import { Router, Request, Response } from 'express';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/authMiddleware';
import { logger } from '../utils/logger';
// import { 
//   getTemplates, 
//   getProjects, 
//   checkExistingVersion, 
//   saveTemplateVersion,
//   Template,
//   Project 
// } from '../services/supabaseService';
// import { generateContent, generateBilingualContent } from '../services/aiService';

const router = Router();

interface HistoryItem {
  id: string;
  type: string;
  status: string;
  createdAt: string;
}

// 批量生成模板
router.post('/batch-generate', asyncHandler(async (req: AuthRequest, res: Response): Promise<void> => {
  const {
    languages = ['zh'],
    templateIds,
    categoryCode = '',
    limit = 10,
    tableName = 'user_projects',
    testMode = false,
    demoMode = false,
    batchSize = 1,
    templateBatchSize = 1,
    maxExecutionTime = 300000, // 5分钟，无30秒限制
    startOffset = 0,
    templateOffset = 0,
    autoNext = false
  } = req.body;

  const userId = req.user?.id;

  logger.info('🚀 开始批量生成模板...', {
    languages,
    templateIds,
    categoryCode,
    limit,
    userId,
    tableName,
    testMode,
    demoMode,
    batchSize,
    templateBatchSize,
    maxExecutionTime,
    startOffset,
    templateOffset,
    autoNext
  });

  try {
    // 演示模式处理
    if (demoMode) {
      const demoResult = await handleDemoMode(languages);
      res.json(demoResult);
      return;
    }

    // 真实模式处理
    const result = await handleBatchGeneration({
      languages,
      templateIds,
      categoryCode,
      limit,
      userId,
      tableName,
      testMode,
      batchSize,
      templateBatchSize,
      maxExecutionTime,
      startOffset,
      templateOffset,
      autoNext
    });

    res.json(result);
  } catch (error) {
    logger.error('批量生成模板失败', error);
    throw createError('批量生成模板失败', 500);
  }
}));

// 获取模板列表
router.get('/list', asyncHandler(async (req: AuthRequest, res: Response) => {
  const { category, limit = 25, offset = 0 } = req.query;
  
  // TODO: 实现从Supabase获取模板列表
  const templates = [
    {
      id: '1',
      name_zh: '产品需求文档',
      name_en: 'Product Requirements Document',
      category: 'product-management'
    }
  ];

  res.json({
    templates,
    total: templates.length,
    limit: Number(limit),
    offset: Number(offset)
  });
}));

// 获取生成历史
router.get('/history', asyncHandler(async (req: AuthRequest, res: Response) => {
  const userId = req.user?.id;
  const { limit = 20, offset = 0 } = req.query;

  // TODO: 实现从数据库获取生成历史
  const history: HistoryItem[] = [];

  res.json({
    history,
    total: history.length,
    limit: Number(limit),
    offset: Number(offset)
  });
}));

// 演示模式处理函数
async function handleDemoMode(languages: string[]) {
  logger.info('🎭 进入演示模式，使用模拟数据测试...');
  
  return {
    generated: 1,
    skipped: 0,
    errors: 0,
    details: [{
      project: 'AI智能助手产品-演示',
      template: '产品需求文档',
      status: 'generated',
      content: '这是演示生成的内容...'
    }],
    timeout_reached: false,
    batch_completed: true,
    execution_time: '2.5s',
    next_batch_url: null
  };
}

// 批量生成处理函数
async function handleBatchGeneration(params: any) {
  const {
    languages,
    templateIds,
    categoryCode,
    limit,
    userId,
    tableName,
    testMode,
    batchSize,
    templateBatchSize,
    maxExecutionTime,
    startOffset,
    templateOffset,
    autoNext
  } = params;

  const startTime = Date.now();
  
  logger.info('处理批量生成请求', {
    languages,
    limit,
    batchSize,
    templateBatchSize,
    maxExecutionTime
  });

  // 模拟批量生成过程
  await new Promise(resolve => setTimeout(resolve, 1000));

  const results = {
    generated: 2,
    skipped: 1,
    errors: 0,
    details: [
      {
        project: 'AI智能助手产品',
        template: '产品需求文档',
        status: 'generated',
        language: languages[0] || 'zh'
      },
      {
        project: 'AI智能助手产品',
        template: 'Product Requirements Document', 
        status: 'generated',
        language: 'en'
      },
      {
        project: '区块链钱包应用',
        template: '市场趋势分析',
        status: 'skipped',
        reason: '已存在版本'
      }
    ],
    timeout_reached: false,
    batch_completed: true,
    execution_time: `${((Date.now() - startTime) / 1000).toFixed(1)}s`,
    next_batch_url: null
  };

  logger.info('批量生成完成', {
    generated: results.generated,
    skipped: results.skipped,
    errors: results.errors,
    executionTime: results.execution_time
  });

  return results;
}

export default router; 