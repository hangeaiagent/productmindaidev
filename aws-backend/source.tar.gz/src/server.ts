import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import { createServer } from 'http';

// 导入路由
import templateRoutes from './routes/templateRoutes';
import healthRoutes from './routes/healthRoutes';
import queueRoutes from './routes/queueRoutes';

// 导入中间件
import { errorHandler } from './middleware/errorHandler';
import { requestLogger } from './middleware/requestLogger';
import { authMiddleware } from './middleware/authMiddleware';

// 导入服务
import { logger } from './utils/logger';
// import { connectRedis } from './services/redisService'; // 临时注释

// 加载环境变量
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// 基础中间件
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

app.use(compression());
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// CORS配置
const corsOptions = {
  origin: process.env.CORS_ORIGIN?.split(',') || ['http://localhost:5173'],
  credentials: true,
  optionsSuccessStatus: 200,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
};
app.use(cors(corsOptions));

// 速率限制
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'), // 15分钟
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100'), // 限制每个IP 100个请求
  message: {
    error: '请求过于频繁，请稍后再试',
    retryAfter: '15分钟'
  },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// 请求日志中间件
app.use(requestLogger);

// 健康检查路由（不需要认证）
app.use('/health', healthRoutes);

// 测试路由（不需要认证）
app.get('/test/templates', async (req, res) => {
  try {
    res.json({
      message: '模板生成服务测试端点',
      status: 'ok',
      timestamp: new Date().toISOString(),
      features: [
        'batch-generate: 批量生成模板',
        'queue: 队列管理',
        'redis: 缓存服务'
      ]
    });
  } catch (error: any) {
    res.status(500).json({ error: '测试端点错误', message: error.message });
  }
});

// 测试批量生成（演示模式，不需要认证）
app.post('/test/batch-generate', async (req, res) => {
  try {
    const { demoMode = true, languages = ['zh'] } = req.body;
    
    logger.info('🎭 演示模式批量生成测试', { demoMode, languages });
    
    // 模拟批量生成结果
    const mockResult = {
      generated: 2,
      skipped: 1,
      errors: 0,
      details: [
        {
          project: 'AI智能助手产品-演示',
          template: '产品需求文档',
          status: 'generated',
          content: '这是演示生成的产品需求文档内容...',
          language: 'zh'
        },
        {
          project: 'AI智能助手产品-演示',
          template: 'Product Requirements Document',
          status: 'generated', 
          content: 'This is a demo generated PRD content...',
          language: 'en'
        },
        {
          project: '区块链钱包应用',
          template: '市场趋势分析',
          status: 'skipped',
          reason: '已存在版本'
        }
      ],
      timeout_reached: false,
      batch_completed: true,
      execution_time: '2.5s',
      next_batch_url: null
    };
    
    res.json(mockResult);
  } catch (error: any) {
    res.status(500).json({ error: '测试批量生成失败', message: error.message });
  }
});

// API路由（需要认证）
app.use('/api/v1/templates', authMiddleware, templateRoutes);
app.use('/api/v1/queue', authMiddleware, queueRoutes);

// 根路径
app.get('/', (req, res) => {
  res.json({
    message: 'ProductMind AI AWS Backend Service',
    version: process.env.API_VERSION || 'v1',
    status: 'running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// 404处理
app.use('*', (req, res) => {
  res.status(404).json({
    error: '接口不存在',
    path: req.originalUrl,
    method: req.method,
    timestamp: new Date().toISOString()
  });
});

// 错误处理中间件
app.use(errorHandler);

// 创建HTTP服务器
const server = createServer(app);

// 优雅关闭处理
const gracefulShutdown = (signal: string) => {
  logger.info(`收到 ${signal} 信号，开始优雅关闭...`);
  
  server.close(() => {
    logger.info('HTTP服务器已关闭');
    
    // 关闭Redis连接
    // redisClient.quit();
    
    process.exit(0);
  });

  // 强制关闭超时
  setTimeout(() => {
    logger.error('强制关闭服务器');
    process.exit(1);
  }, 10000);
};

// 监听关闭信号
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// 未捕获异常处理
process.on('uncaughtException', (error) => {
  logger.error('未捕获的异常:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('未处理的Promise拒绝:', { reason, promise });
  process.exit(1);
});

// 启动服务器
async function startServer() {
  try {
    // 尝试连接Redis，但不阻塞服务器启动
    try {
      // await connectRedis();
    } catch (redisError) {
      logger.warn('Redis连接失败，但服务器将继续启动:', redisError);
    }
    
    server.listen(PORT, () => {
      logger.info(`🚀 服务器启动成功！`);
      logger.info(`📍 端口: ${PORT}`);
      logger.info(`🌍 环境: ${process.env.NODE_ENV || 'development'}`);
      logger.info(`🔗 健康检查: http://localhost:${PORT}/health`);
      logger.info(`📚 API文档: http://localhost:${PORT}/api/v1`);
    });
  } catch (error) {
    logger.error('服务器启动失败:', error);
    process.exit(1);
  }
}

startServer();

export default app; 